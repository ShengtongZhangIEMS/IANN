# IANN
It is a function visualization package for Interpretable Architecture Neural Network (IANN)

It has two classes inside

References:

