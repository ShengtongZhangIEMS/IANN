from .module import iann_class
from .regressor import IANNModel