# IANN
It is a function visualization package for Interpretable Architecture Neural Network (IANN)

It has three different structures:
Original Variable Hierarchical (OVH)
Disjoint Active Subspace Hierarchical (DASH)
Additive 

References:

